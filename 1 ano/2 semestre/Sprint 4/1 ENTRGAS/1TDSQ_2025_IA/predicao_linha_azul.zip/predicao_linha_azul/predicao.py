import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.multioutput import MultiOutputRegressor
from sklearn.metrics import r2_score
import joblib

# 1. Ler CSV corretamente
df = pd.read_csv("Dataset_azul.csv", sep=";", decimal=",")
df.columns = df.columns.str.strip()

# 2. Codificar categorias
label_encoder_linha = LabelEncoder()
label_encoder_mes = LabelEncoder()
df["LINHA"] = label_encoder_linha.fit_transform(df["LINHA"])
df["MES"] = label_encoder_mes.fit_transform(df["MES"])

# 3. Definir variáveis
estacoes = ["JAB", "CON", "JUD", "SAU", "ARV", "SCZ", "VMN", "ANR", "PSO", "VGO",
            "JQM", "LIB", "PSE", "BTO", "TRD", "PPQ", "TTE", "CDU", "SAN", "JPA", "PIG", "TUC", "LUZ"]

X = df[["LINHA", "MES", "DIA"]]
y = df[estacoes]

# 4. Normalizar
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 5. Treino/teste
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.3, random_state=42)

# 6. Modelo multivariado
modelo = MultiOutputRegressor(RandomForestRegressor(random_state=42))
modelo.fit(X_train, y_train)

# 7. Avaliação
y_pred = modelo.predict(X_test)
score = r2_score(y_test, y_pred, multioutput='uniform_average')
print(f"R² médio: {score:.4f}")

# 8. Salvar arquivos
joblib.dump(modelo, "modelo.pkl")
joblib.dump(scaler, "scaler.pkl")
joblib.dump(label_encoder_linha, "encoder_linha.pkl")
joblib.dump(label_encoder_mes, "encoder_mes.pkl")

print("Modelo salvo com sucesso!")

from flask import Flask, request, jsonify, render_template
import joblib
import numpy as np
import pandas as pd

app = Flask(__name__)

# Carregar modelo e pré-processadores
modelo = joblib.load("modelo.pkl")
scaler = joblib.load("scaler.pkl")
encoder_linha = joblib.load("encoder_linha.pkl")
encoder_mes = joblib.load("encoder_mes.pkl")

df_original = pd.read_csv("Dataset_azul.csv", sep=";", decimal=",")
df_original.columns = df_original.columns.str.strip()

estacoes = ["JAB", "CON", "JUD", "SAU", "ARV", "SCZ", "VMN", "ANR", "PSO", "VGO",
            "JQM", "LIB", "PSE", "BTO", "TRD", "PPQ", "TTE", "CDU", "SAN", "JPA", "PIG", "TUC", "LUZ"]

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        linha = request.form["linha"]
        mes = request.form["mes"]
        dia = int(request.form["dia"])

        linha_encoded = encoder_linha.transform([linha])[0]
        mes_encoded = encoder_mes.transform([mes])[0]

        entrada = np.array([[linha_encoded, mes_encoded, dia]])
        entrada_scaled = scaler.transform(entrada)

        predicoes = modelo.predict(entrada_scaled)[0]
        predicoes_dict = dict(zip(estacoes, map(lambda x: round(x, 2), predicoes)))

        return render_template("index.html", predicao=predicoes_dict)

    return render_template("index.html", predicao=None)

@app.route("/api/predict", methods=["POST"])
def predict_api():
    dados = request.json
    linha = encoder_linha.transform([dados["linha"]])[0]
    mes = encoder_mes.transform([dados["mes"]])[0]
    dia = dados["dia"]

    entrada = np.array([[linha, mes, dia]])
    entrada_scaled = scaler.transform(entrada)
    predicoes = modelo.predict(entrada_scaled)[0]

    return jsonify(dict(zip(estacoes, map(lambda x: round(x, 2), predicoes))))

@app.route("/buscar_dados", methods=["POST"])
def buscar_dados():
    linha = request.form["linha"]
    mes = request.form["mes"]
    dia = int(request.form["dia"])

    dados_linha = df_original[
        (df_original["LINHA"] == linha) &
        (df_original["MES"] == mes) &
        (df_original["DIA"] == dia)
    ]

    if dados_linha.empty:
        return "Não encontrado", 404

    dados_estacoes = dados_linha.iloc[0].drop(["LINHA", "MES", "DIA"]).to_dict()
    return jsonify(dados_estacoes)

if __name__ == "__main__":
    app.run(debug=True)
